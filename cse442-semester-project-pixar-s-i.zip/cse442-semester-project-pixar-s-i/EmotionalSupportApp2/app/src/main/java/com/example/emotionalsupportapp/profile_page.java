package com.example.emotionalsupportapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class profile_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);
    }
}
